# NexaConnect AI Customer Support Assistant

Case Study 1 prototype — an AI-powered support assistant that answers customer
enquiries, classifies them, detects urgency/sentiment, and escalates complex
cases to a human agent.

## Structure

```
frontend/
  index.html        - Chat UI (currently uses local keyword logic — will be
                       updated to call the live backend in the next step)
backend/
  server.js          - Express server, calls the Claude API, returns
                        answer + category + urgency + sentiment + escalation
  package.json        - Dependencies (express, cors)
  knowledgeBase.json  - FAQ/policy content fed to the AI as context
  .env.example        - Shows the required environment variable name
  .gitignore          - Keeps node_modules and .env out of git
```

## Setup

1. Push the `backend/` folder to a GitHub repo.
2. Get a Claude API key from console.anthropic.com.
3. Deploy the repo on Render.com as a Web Service:
   - Build command: `npm install`
   - Start command: `npm start`
   - Add environment variable: `CLAUDE_API_KEY` = your key
4. Render will give you a live URL (e.g. `https://your-app.onrender.com`).
5. Update `frontend/index.html` to call `https://your-app.onrender.com/api/chat`
   instead of the local keyword logic (next build step).

## Endpoints

- `POST /api/chat` — body: `{ "message": "..." }`, returns AI answer +
  classification + escalation flag.
- `GET /api/log` — returns the in-memory interaction log (for reporting).

## Business value

Automates responses to repetitive enquiries (tracking, delivery, payment,
returns, refunds, product info), classifies and flags urgent/negative
messages, and routes only complex or low-confidence cases to human agents —
reducing response time and freeing up the support team for harder cases.
