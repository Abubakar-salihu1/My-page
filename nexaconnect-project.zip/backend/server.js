const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const CLAUDE_API_KEY = process.env.CLAUDE_API_KEY;

// Load knowledge base
const knowledgeBase = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'knowledgeBase.json'), 'utf8')
);

// In-memory interaction log (resets on server restart - fine for a prototype)
const interactionLog = [];

app.get('/', (req, res) => {
  res.send('NexaConnect Support Assistant backend is running.');
});

app.post('/api/chat', async (req, res) => {
  const { message } = req.body;

  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'A "message" string is required.' });
  }

  if (!CLAUDE_API_KEY) {
    return res.status(500).json({ error: 'Server is missing CLAUDE_API_KEY.' });
  }

  const systemPrompt = `You are a customer support assistant for NexaConnect, an online retail company.
Use the knowledge base below to answer customer questions accurately.

KNOWLEDGE BASE:
${JSON.stringify(knowledgeBase, null, 2)}

Respond ONLY with a JSON object (no markdown, no code fences, no extra text) in this exact shape:
{
  "answer": "<your reply to the customer, based on the knowledge base if relevant>",
  "category": "<one of: delivery, payment, refund, complaint, product, general>",
  "urgency": "<one of: low, medium, high>",
  "sentiment": "<one of: positive, neutral, negative>",
  "confident": <true or false, whether you could answer this from the knowledge base>
}

If the question cannot be answered from the knowledge base, or the customer is upset/urgent, set "confident" to false and "urgency" to "high" as appropriate.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CLAUDE_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 500,
        system: systemPrompt,
        messages: [{ role: 'user', content: message }]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Claude API error:', data);
      return res.status(502).json({ error: 'AI service error.' });
    }

    const rawText = data.content?.find(block => block.type === 'text')?.text || '{}';
    const cleaned = rawText.replace(/```json|```/g, '').trim();

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (parseErr) {
      console.error('Failed to parse AI JSON:', rawText);
      parsed = {
        answer: "I'm having trouble processing that. Let me escalate this to a human agent.",
        category: 'general',
        urgency: 'medium',
        sentiment: 'neutral',
        confident: false
      };
    }

    const escalated = parsed.urgency === 'high' || parsed.confident === false;

    const logEntry = {
      timestamp: new Date().toISOString(),
      customerMessage: message,
      answer: parsed.answer,
      category: parsed.category,
      urgency: parsed.urgency,
      sentiment: parsed.sentiment,
      escalated
    };
    interactionLog.push(logEntry);

    res.json({ ...parsed, escalated });
  } catch (err) {
    console.error('Server error:', err);
    res.status(500).json({ error: 'Something went wrong on the server.' });
  }
});

// View the interaction log (for the "reporting" requirement)
app.get('/api/log', (req, res) => {
  res.json(interactionLog);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
